#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <ucontext.h>
#include <errno.h>
#include <unistd.h>
#include <sys/time.h>

#include "my_pthread_t.h"

#define DEFAULT_INTERVAL_0 100
/*
 * Simple file showing our thread library working.
 */
int i = 0;
my_pthread_mutex_t * mutex;
struct timeval tv;
void *printForever(void *str) {
    int j=0;
    char * string = (char *) str;
    for (; j < 1; j++){
        char * f = malloc(1000);
        void * a = malloc(1000);
        my_pthread_yield();
        void * b = malloc(1000);

        // test_func();
        my_pthread_yield();
        char * c = malloc(1000);
        my_pthread_yield();
        void * d = malloc(1080);
        a = malloc(1000);
        b = malloc(1000);
        c = malloc(1000);
        d = malloc(1080);
        my_pthread_yield();
        char * e = malloc(77);

        my_pthread_yield();

        free(a);
        a = malloc(500);
        sprintf(f, "first page test %s", string);
        sprintf(e, "second page test %s", string);
        my_pthread_yield();

        sprintf(c, "third page test %s", string);
        my_pthread_yield();
        printf("f=%s", f);
        printf("e=%s", e);
        printf("c=%s", c);
        sprintf(c, "third page test2 %s", string);
        printf("f=%s", f);
        printf("e=%s", e);
        printf("c=%s", c);
    }
    // char * f = malloc(1000);
    // char * f2 = malloc(1000);
    // char * f3 = malloc(1000);
    // char * f4 = malloc(1000);
    // char * f5 = malloc(1000);
    // free(f5);
	return NULL;
}
struct timeval GetTimeStamp() {
    struct timeval tv;
    gettimeofday(&tv,NULL);
    return tv;
}
int main(int argc, char *argv[]) {

    char * a = malloc(10);
    a = "first\n\0";
    char * b = malloc(10);
    b = "second\n\0";
    char * c = malloc(10);
    c = "third\n\0";

    mutex = malloc(sizeof(my_pthread_mutex_t));
    my_pthread_t * threads = malloc(sizeof(my_pthread_t) * 3);

    my_pthread_create(&threads[0], NULL, printForever, (void *) a);

    my_pthread_create(&threads[1], NULL, printForever, (void *) b);
    my_pthread_join(threads[0], NULL);
    my_pthread_join(threads[0], NULL);
    // my_pthread_join(threads[1], NULL);
    // my_pthread_join(threads[2], NULL);
    return 0;
}
