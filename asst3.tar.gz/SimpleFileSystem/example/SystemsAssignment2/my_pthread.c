#include <stdio.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/mman.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include "my_pthread_t.h"
//Interval for highest priority
#define DEFAULT_INTERVAL_2  10 

//Interval for second highest priority
#define DEFAULT_INTERVAL_1   20

#define PAGESIZE sysconf( _SC_PAGESIZE)
#define SIZE 8388608
#define FILESIZE 16777216
//Pages reserved for system memory
#define LIBRARY_MEM 500 

#define DEFAULT_STACK_SIZE PAGESIZE*5
#define MALLOC_CONST LIBRARY_MEM*PAGESIZE
 //Interval for lowest priority
#define DEFAULT_INTERVAL_0   40

//how many times it can run in the highest priority
#define FIRSTBREAKINGPOINT 1

//how many times it can run in the second highest priority
#define SECONDBREAKINGPOINT 8

//If a thread hasn't run in this many cycles increase priority
#define PRIORITY_INCREASE_INTERVAL 1


static volatile int initialized = 0;
int total_pages = 0;
int yielded = 0;
int curFilePage = 1;
int swapCounter = 1;

FILE * filedes = 0;

//this is a bitmap of size ceiling(total amount of pages/32)
//if the ith bit is 0 then the ith page is free.
//if the ith bit is 1 then the ith page is being used.
int * pageDirectory = 0;

//This is a pointer the memory that is reserved for the thread library
void * systemMemory = 0;

//This is the address of the first page for threads in memory
void * firstPage = 0;

//Address of a free page used for when reading things in from the swap file
void * swapSpace = 0;

//Stores the order of the pages in a linked list
LinkedList *pageOrder = 0;

// Queues for running and waiting threads
hash *threadQueue = 0;

//Sometimes swapping a page would cause a segfault that would be handled, 
//but then the page would be switched twice, so this is set to 1 in the handler
//and 0 before calling swapPage();
int breakFromSwapPage = 0;
pageTable * pTable = 0;

LinkedList *runQueue0 = 0;
LinkedList *runQueue1 = 0;
LinkedList *runQueue2 = 0;

LinkedList *waitQueue = 0;
mutexhash *mutexQueue = 0;
my_pthread_t_element * currentlyRunning = 0;
my_pthread_t_element * oldRunning = 0;


static volatile unsigned int ID = 1;
static volatile unsigned int MUTEX_ID = 1;
static volatile unsigned int executionCounter = 1;

// finished_context is linked to each thread through uc_link. Once a threaded function returns,
// the finished_context is switched to (inside thread_terminated) so that the thread can exit
// and call the scheduler once again.
ucontext_t finished_context, *main_context;

// itimerval of 0 for timer cancelation. I keep this copy to avoid time wasted initializing
// the structure, when we want to cancel the timer as quickly as possible. 
struct itimerval cancel_time = {0};
struct itimerval old_timer;
/*
 * !!!!!!!!!!!!!!!!!!! 
 * START OF MALLOC CODE
 * !!!!!!!!!!!!!!!!!!!
 */
static char * myblock = 0;


void * split(int * p, int bytesOrOne, int toAdd){
	if (*p == (bytesOrOne-1)){
		*p = bytesOrOne;
		void * toReturn = ((void *)p)+4;
		return toReturn;
	}

	if (*p != 0 && (*p)-6 <= (bytesOrOne-1)){
		*p += 1;
		void * toReturn = ((void *)p)+4;
		return toReturn;
	}
	int oldValue = *p == 0 ? (SIZE-4) : *p;
	*p = bytesOrOne;
	void * toReturn = ((void *)p)+4;
	int * p1 = (int *) (&myblock[(toAdd + 4 + bytesOrOne - 1)]);

	int newValue = (oldValue - (4 + (bytesOrOne - 1)));
    *p1 = newValue;
	return toReturn;
}

void * mymalloc(int bytes, char * file, int line, int THREADREQ){
	
	if (!myblock){
		posix_memalign((void *)&myblock, sysconf(_SC_PAGE_SIZE), SIZE);
        memset(myblock, 0, SIZE);
	}
    if (THREADREQ == 0 && initialized && currentlyRunning->id != 1){
    	int * threadFirstPage = ((int *) getHead(currentlyRunning->pages)->value);
    	int tempval = *threadFirstPage;
        return mymallocPage(firstPage + PAGESIZE*tempval, PAGESIZE * currentlyRunning->pageCount, bytes, file,line,THREADREQ);        
    }
    if (THREADREQ == 0 && (!initialized || currentlyRunning->id == 1)){
    	systemMemory = myblock;
        return mymallocPage(systemMemory, MALLOC_CONST, bytes, file,line,2);
    }

	if (bytes % 2 == 1){bytes++;}
	if (bytes == 0){
		return NULL;
	}
	int * p = (int *) (&myblock[0]);
	int bytesOrOne = (bytes | 1);
	if (*p == 0){
		return split(p,bytesOrOne,0);
	}
	int toAdd = 0;
	while((void *)p < (void *)&myblock[SIZE]){
		if ((*p & 1) == 1 || *p < bytes){
			int oldValue = *p;
			if (oldValue % 2 == 1){
				oldValue--;
			}
			p = (int *) (&myblock[(toAdd+oldValue + 4)]);
			toAdd+=oldValue+4;
			
		}
		else if (*p >= bytes){
			return split(p,bytesOrOne, toAdd);
		}
	}
	// int * threadFirstPage = ((int *) getHead(currentlyRunning->pages)->value);
	// int tempval = *threadFirstmPage;
	// printf("%d\n", tempvalm);
	return NULL;
}

void * splitPage(char * tempblock, int pageSize, int * p, int bytesOrOne, int toAdd){
	if (*p == (bytesOrOne-1)){
		*p = bytesOrOne;
		void * toReturn = ((void *)p)+4;
		return toReturn;
	}
	if (*p != 0 && (*p)-6 <= (bytesOrOne-1)){
		*p += 1;
		void * toReturn = ((void *)p)+4;
		return toReturn;
	}

	int oldValue = *p == 0 ? (pageSize-4) : *p;
	*p = bytesOrOne;
	void * toReturn = ((void *)p)+4;
	int * p1 = (int *) (tempblock + toAdd + 4 + bytesOrOne - 1);

	int newValue = (oldValue - (4 + (bytesOrOne - 1)));
    *p1 = newValue;
	return toReturn;
}

//Simple debug method that prints the first ten items of PageOrder
//was used to test swapPageOrder/swapPages
void printfirstten(){
	int i = 0;
	for (;i < 10; i++){
		int movingPageID = *((int *)getLink(pageOrder, i)->value);
		//printf("%d = %d\n", i, movingPageID);
	}
}

//Swaps two elements in the pageOrder list, is called by swapPages you should
//never have to call this method
void swapPageOrder(int from, int to){
	pageTableEntry * fromPTE = getPageTableEntry(pTable, from), * toPTE = getPageTableEntry(pTable, to);
	unsigned int fromPage = (fromPTE->address - firstPage)/PAGESIZE, toPage = (toPTE->address - firstPage)/PAGESIZE;
	LinkedNode * temp1 = getLink(pageOrder, fromPage), * temp2 = getLink(pageOrder, toPage);
	void * switchVal = temp1->value;
	temp1->value = temp2->value;
	temp2->value = switchVal;
}

/*
 * This method takes in two pagetableentry ids and swaps them in memory, and then 
 * swaps them in the pageOrder list
 */
void swapPages(int from, int to){
	int i = 0;
    //printf("swapped %d and %d \n", from, to);
	pageTableEntry * fromPTE = getPageTableEntry(pTable, from), * toPTE = getPageTableEntry(pTable, to);
	char * fromPage = fromPTE->address, * toPage = toPTE->address;
	for (;i < PAGESIZE; i++){
		char temp = *(fromPage+i);
		*(fromPage + i) = *(toPage + i);
		if (breakFromSwapPage) {
			*(fromPage + i) = temp;
			return;
		}
		*(toPage + i) = temp;
	}
	void * temp = fromPTE->address;
	fromPTE->address = toPTE->address;
	toPTE->address = temp;
	swapPageOrder(from, to);
}

//Is called when malloc cannot allocate enough space for a thread
//it requests another page of memory and then swaps that page into its 
//proper space.
int requestNextPage(){
	int * next_page = mymallocPage(systemMemory, MALLOC_CONST, sizeof(int), __FILE__, __LINE__, 2);
	*next_page = getNextFreePage();
	if (*next_page == -1){
		return 0;
	}
	addLink(currentlyRunning->pages, (void *)next_page);
	int * threadFirstPage = ((int *) getHead(currentlyRunning->pages)->value);
    int tempval = *threadFirstPage;
    int moving = tempval + (currentlyRunning->pageCount++);
    int movingPageID = *((int *)getLink(pageOrder, moving)->value);
    breakFromSwapPage = 0; 
    swapPages(movingPageID, *next_page);
    // printf("gave thread %d page %d\n", currentlyRunning->id, *next_page);
    return 1;
}
void fixSystemMemory() {
    int * p = (int*)(systemMemory);
	int toAdd = 0;
    int * last;
	int j = 0;
	while ((void *)p <= (void *)systemMemory+MALLOC_CONST && *p != 0){		
		int oldValue = *p;
        last = p;
		printf("found a %d at %li\n", *p, ((void *)p - (void *)systemMemory));
		p = (int *) (systemMemory+(toAdd+(oldValue&~1) + 4));
		toAdd+=(oldValue&~1)+4;
	}
    printf("*last = %d\n", *last);
    *last = toAdd&~1;

}
void * mymallocPage(char * tempblock, int pageSize, int bytes, char * file, int line, int THREADREQ){
	bytes += bytes & 1;	// only allocate on 2 byte boundaries
	if (bytes == 0){
		return NULL;
	}
	int * p = (int *) tempblock;
	int * old;
	int bytesOrOne = (bytes | 1);
	if (*p == 0){
        if (tempblock != systemMemory) {
            while (bytes > pageSize){
                requestNextPage();
                pageSize+=PAGESIZE;
            }
        }
        //printf("pageSize = %d\n", pageSize);
		return splitPage(tempblock, pageSize, p,bytesOrOne,0);
	}
	int toAdd = 0;
	while((void *)p < (void *)(tempblock + pageSize)){
		if ((*p & 1) == 1 || *p < bytes){
			int oldValue = *p;
			if (oldValue % 2 == 1){
				oldValue--;
			}
			old = p;
			p = (int *) (tempblock + toAdd+oldValue + 4);
			toAdd+=oldValue+4;
		}
		else if (*p >= bytes){
			return splitPage(tempblock, pageSize, p,bytesOrOne, toAdd);
		}
	}
	if (((void *)tempblock + PAGESIZE*currentlyRunning->pageCount + PAGESIZE > (void *) myblock+SIZE) && (tempblock != systemMemory)){
        //printf("returned null?\n");
		return NULL;
	}
	if (tempblock != systemMemory && requestNextPage()){
		if (*old & 1) {
			*p = PAGESIZE;
		}
		else *old += PAGESIZE;
        //printf("here\n");
		return mymallocPage(tempblock, PAGESIZE*currentlyRunning->pageCount, bytes, file, line, THREADREQ);
	}
	return NULL;
}

/**
 *
 **/
void combine(){
	int * current = (int*)(&myblock[0]);
	int * prev = NULL;
	int toAdd = 0;
	int callAgain = 0;
	while((void *)current < (void *)&myblock[SIZE] && *current != 0){	
		int currentValue = *current;
		int prevValue = prev == NULL ? 1:*prev;
		if (currentValue % 2 == 0 && (prevValue % 2 == 0)){
			*prev = currentValue+prevValue + 4;
			current = (void *)(&myblock[(toAdd + currentValue + 4)]);
			callAgain = 1;
			break;
		}
		else{
			prev = current;
			if (currentValue %2 == 1){
				currentValue--;
			}
			current = (int *) (&myblock[(toAdd + (currentValue) + 4)]);
			toAdd += currentValue + 4;

		}
	}
	if (callAgain){
		combine();
	}
	//TODO Add check for free pages
}

/** 
 * Prints the implicit list in malloc.
 **/
void printMallocHeap(int i){
	int * p = (int*)(myblock);
	int toAdd = 0;
	int j = 0;
	while ((void *)p < (void *)&myblock[SIZE-1] && *p != 0 && j++ < i){		
		int oldValue = *p;
		//printf("found a %d at %li\n", *p, ((void *)p - (void *)&myblock[0]));
		p = (int *) (&myblock[(toAdd+(oldValue&~1) + 4)]);
		toAdd+=(oldValue&~1)+4;
	}
}
void combinePage(char * tempblock, int pageSize){
	int * current = (int*)(&tempblock[0]);
	int * prev = NULL;
	int toAdd = 0;
	int callAgain = 0;
	while((void *)current < (void *)&tempblock[pageSize] && *current != 0){	
		int currentValue = *current;
		int prevValue = prev == NULL ? 1:*prev;
		if (currentValue % 2 == 0 && (prevValue % 2 == 0)){
			*prev = currentValue+prevValue + 4;
			current = (void *)(&tempblock[(toAdd + currentValue + 4)]);
			callAgain = 1;
			break;
		}
		else{
			prev = current;
			if (currentValue %2 == 1){
				currentValue--;
			}
			current = (int *) (&tempblock[(toAdd + (currentValue) + 4)]);
			toAdd += currentValue + 4;

		}
	}
	if (callAgain){
		combinePage(tempblock, pageSize);
	}
	//TODO Add check for free pages
}

//Checks if the thread is actually using the pages it has
void checkUsage(char * tempblock, int pageSize){
	int * p = (int *) tempblock;
	int * old;
	int toAdd = 0;
	while((void *)p < (void *)(tempblock + pageSize)){
		int oldValue = *p;
		if (oldValue % 2 == 1){
			oldValue--;
		}
		old = p;
		p = (int *) (tempblock + toAdd+oldValue + 4);
		toAdd+=oldValue+4;
	}
	if (tempblock != systemMemory){
		if (*old & 1) {
			return;
		}
		else if (*old > PAGESIZE){
			*old -= PAGESIZE;
			// printf("length = %d\n", currentlyRunning->pages->length);
			int page = *((int *)popLast(currentlyRunning->pages));
			// printf("no longer using page %d\n", page);
			// printf("length = %d\n", currentlyRunning->pages->length);
			setPageFree(page);
		};
	}
}
void * myfreePage(char * tempblock, int pageSize, void * toFree, char * file, int line, int THREADREQ){
	if (toFree < (void *) &tempblock[0] || toFree > (void *) &tempblock[pageSize-1]){
		printf("ERROR: pointer given to free from file %s at line %d caused free to error\n", file, line);
		exit(1);
	}
	int * p = (int *) ((toFree-4));
	if (*p == 0){
		printf("ERROR: pointer given to free from file %s at line %d caused free to error\n", file, line);
		exit(1);
	}
	if (*p % 2 == 0){
		printf("ERROR: pointer given to free from file %s at line %d was already free\n", file, line);
		exit(1);
	}
	*p = *p - 1;
	combinePage(tempblock, pageSize);
	if (tempblock != systemMemory && currentlyRunning->pages->length != 1)
		checkUsage(tempblock, pageSize);
}
void myfree(void * toFree, char * file, int line, int THREADREQ){
	if (THREADREQ == 0 && initialized){
    	// printf("currentlyRunning = %d\n", currentlyRunning);
    	if (currentlyRunning->id == 1 || (toFree > systemMemory && toFree < systemMemory + MALLOC_CONST)) {
	    	myfreePage(systemMemory, MALLOC_CONST, toFree, file,line,THREADREQ);        
	    }
    	else if (currentlyRunning->id != 1){
	    	int * threadFirstPage = ((int *) getHead(currentlyRunning->pages)->value);
	    	int tempval = *threadFirstPage;
	        myfreePage(firstPage + PAGESIZE*tempval, PAGESIZE * currentlyRunning->pageCount, toFree, file,line,THREADREQ);        
	    }
    }
    else if(THREADREQ == 0 && !initialized){
    	systemMemory = myblock;
    	// printf("currentlyRunning = %d\n", currentlyRunning);
        myfreePage(systemMemory, MALLOC_CONST,toFree, file,line,2);
    }
}
/*
 * !!!!!!!!!!!
 * START OF /HASH CODE
 * !!!!!!!!!!!
 */

hash * initHash(){
	hash * toReturn = mymallocPage(systemMemory, MALLOC_CONST, sizeof(hash), __FILE__, __LINE__, 2);
	toReturn->curLen = 0;
	toReturn->curMaxLen = 512;
	toReturn->hash = mymallocPage(systemMemory, MALLOC_CONST, sizeof(my_pthread_t_element*) * toReturn->curMaxLen, __FILE__, __LINE__, 2);
	return toReturn;
}

void insertHash(hash * h, my_pthread_t_element * toInsert){
	h->hash[toInsert->id] = toInsert;
}

my_pthread_t_element * getHash(hash * h, int id){
	return h->hash[id];
}

mutexhash * initHashMutex(){
	mutexhash * toReturn = mymallocPage(systemMemory, MALLOC_CONST, sizeof(mutexhash), __FILE__, __LINE__, 2);
	toReturn->curLen = 0;
	toReturn->curMaxLen = 50;
	
	toReturn->hash = mymallocPage(systemMemory, MALLOC_CONST, sizeof(my_pthread_mutex_t_element*) * toReturn->curMaxLen, __FILE__, __LINE__, 2);
	return toReturn;
}

void insertHashMutex(mutexhash * h, my_pthread_mutex_t_element * toInsert){
	h->hash[toInsert->id] = toInsert;
}

my_pthread_mutex_t_element * getHashMutex(mutexhash * h, int id){
	return h->hash[id];
}

pageTable * initPageTable(){
	pageTable * toReturn = mymallocPage(systemMemory, MALLOC_CONST, sizeof(pageTable), __FILE__, __LINE__, 2);
	toReturn->curLen = 0;
	toReturn->curMaxLen = 6250;
	toReturn->hash = mymallocPage(systemMemory, MALLOC_CONST, sizeof(pageTableEntry*) * toReturn->curMaxLen, __FILE__, __LINE__, 2);
	return toReturn;
}

void insertPageTable(pageTable * h, pageTableEntry * toInsert){
	h->hash[total_pages] = toInsert;
}

pageTableEntry * getPageTableEntry(pageTable * h, int id){
	return h->hash[id];
}

/*
 * !!!!!!!!!!!
 * END OF DATASTRUCTURE CODE
 * !!!!!!!!!!!
 */


/*
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * START OF OUR LINKED LIST CODE
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 */

/**
 * Allocates a LinkedList that must be free()'d later'
 */
LinkedList *initList() {
	char * toReturn =  mymallocPage(systemMemory, MALLOC_CONST, sizeof(LinkedList), __FILE__, __LINE__, 2);
    memset(toReturn, 0, sizeof(LinkedList));
    return (LinkedList*) toReturn;
}

/**
 * Adds a value to the end of a linked list
 */
void addLink(LinkedList *list, void *val) {
    ////printf("in addLink\n");
	LinkedNode *node = mymallocPage(systemMemory, MALLOC_CONST, sizeof(LinkedNode), __FILE__, __LINE__, 2);
    //printf("after malloc call\n");
	node->value = val;
	if (list->length == 0) {
		list->head = node;
		list->tail = node;
		list->cur = node;
	} else {
		getTail(list)->next = node;
		node->prev = getTail(list);
		list->tail = node;
	}

    //printf("out addLink\n");
	list->length++;
}

/**
 * Inserts value to be at the specified index. 0 is the head element,
 * and list->length inserts it as the tail element. If index < 0, then 
 * the item is inserted at the head, and if index > list->length the item
 * is inserted at the tail.
 */
void insertLink(LinkedList *list, void *val, int index) {
	
	LinkedNode *node = mymallocPage(systemMemory, MALLOC_CONST, sizeof(LinkedNode), __FILE__, __LINE__, 2);
	node->value = val;
	
	if (list->length == 0) {
		// if there are no elements, we simply make this the head
		list->head = node;
		list->tail = node;
	} else if (index <= 0) {
		// if head does not equal null, then we start figuring out where to insert this
		list->head->prev = node;
		node->next = list->head;
		list->head = node;
	} else if (index >= list->length) {
		list->tail->next = node;
		node->prev = list->tail;
		list->tail = node;
	} else {
		LinkedNode *atIndex = getLink(list, index);
		// link to previous node
		getPrev(atIndex)->next = node;
		node->prev = getPrev(atIndex);
		// link to node that used to be at this index
		atIndex->prev = node;
		node->next = atIndex;
	}
	
	list->cur = getHead(list);
	list->index = 0;
	list->length++;
}

/**
 * Removes an object from the linked list. The comparison is by reference,
 * meaning only the pointer address is checked. Copies will not match.
 * 
 * Returns link if a match was found, NULL otherwise
 */
void *removeElem(LinkedList *list, void *val) {
	LinkedNode *node;
	int i;
	
	for (i=0; i<list->length; i++) {
		node = getLink(list, i);
		if (node->value == val) {
			if (node->prev == NULL) {
				// removing the head
				list->head = getNext(node);
				if (list->head != NULL) list->head->prev = NULL;
			} else if (node->next == NULL) {
				// removing tail
				list->tail = getPrev(node);
				if (list->tail != NULL) list->tail->next = NULL;
			} else {
				// a middle node
				getPrev(node)->next = getNext(node);
				getNext(node)->prev = getPrev(node);
			}
			
			list->index = 0;
			list->cur = getHead(list);
			list->length--;
			
			if (list->length == 0) {
				list->head = NULL;
				list->tail = NULL;
			}
			void *value = node->value;
			free(node);
			return value;
		}
	}
	
	return NULL;
}

/**
 * Gets a link in the list at a specific index
 */
LinkedNode *getLink(LinkedList *list, int index) {
	if (index < 0) return NULL;
	if (index >= list->length) return NULL;

	while (list->index < index) {
		list->index++;
		list->cur = getNext(list->cur);
	}

	while (list->index > index) {
		list->index--;
		list->cur = getPrev(list->cur);
	}
	return list->cur;
}

/**
 * Gets a link in the list at a specific index
 */
void * findID(LinkedList * list, unsigned int id) {
	LinkedNode * node = getHead(list), *tail = getHead(list);
	do {
		my_pthread_t_element * cur = (my_pthread_t_element *) (node->value);
		if (cur->id == id) {
			return cur;
		}
		node = node->next;
	} while(node != NULL);
	return NULL;
}


/**
 * Returns, but does not remove, element at a specific index
 */
void *peekElem(LinkedList *list, int index) {
	return getLink(list, index)->value;
}

/**
 * Removes and returns the element at a specific index
 */
void *popElem(LinkedList *list, int index) {
	LinkedNode *node = getLink(list, index);

	if (node->prev == NULL) {
		// removing the head
		list->head = getNext(node);
		if (list->head != NULL) list->head->prev = NULL;
	} else if (node->next == NULL) {
		// removing tail
		list->tail = getPrev(node);
		if (list->tail != NULL) list->tail->next = NULL;
	} else {
		// a middle node
		getPrev(node)->next = getNext(node);
		getNext(node)->prev = getPrev(node);
	}
	
	list->index = 0;
	list->cur = getHead(list);
	list->length--;
	
	if (list->length == 0) {
		list->head = NULL;
		list->tail = NULL;
	}

	void *value = node->value;
	free(node);
	return value;
}

/**
 * Returns, but does not remove, the first element of the list
 */
void *peekFirst(LinkedList *list) {
	return getHead(list)->value;
}

/**
 * Removes and returns the first element in the list
 */
void *popFirst(LinkedList *list) {
	LinkedNode *node = getHead(list);
	if (node) {
		list->head = node->next;
		list->length--;
		list->cur = list->head;
		list->index = 0;
	} 

	if (list->length == 0) {
		// head should already equal NULL
		list->tail = NULL;
	} else {
		getHead(list)->prev = NULL;
	}

	void *value = node->value;
	free(node);
	return value;
}

/*
 * Simple getter for queue length.
 */
int getLength(LinkedList * list){
    if (!list) return 0;
    return list->length;
}

/**
 * Returns, but does not remove, the last element in the list
 */
void *peekLast(LinkedList *list) {
	return getTail(list)->value;
}
/**
 * Returns, but does not remove, the last element in the list
 */
//void printList(LinkedList *list) {
//	LinkedNode *node = getHead(list);
//	int i = getLength(list);
//	while (i > 0){
//		my_pthread_t_element * temp = (my_pthread_t_element *) node->value;
//		printf("ID = %d\n", temp->id);
//		node = node->next;
//		i--;
//	}
//	return;
//}
/**
 * Removes and returns the last element in the list
 */
void *popLast(LinkedList *list) {
	LinkedNode *node = getTail(list);
	if (node) {
		list->tail = node->prev;
		list->length--;
		list->cur = list->head;
		list->index = 0;
	} 

	if (list->length == 0) {
		// tail should already equal NULL
		list->head = NULL;
	} else {
		getTail(list)->next = NULL;
	}

	void *value = node->value;
	free(node);
	return value;
}

/*
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * END OF LINKED LIST CODE
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 */
//when something is running set priority to like -1 so you can always get it.
//

/*
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 * START OF OUR PTHREAD CODE
 * !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 */

void resetPriorities(){
	while (getLength(runQueue1) > 0) {
		addLink(runQueue2, (void *) popFirst(runQueue1));
	}
	while (getLength(runQueue0) > 0) {
		addLink(runQueue2, (void *) popFirst(runQueue0));
	}
}

my_pthread_t_element * getNextThread(){
	
	if (getLength(runQueue2) > 0) {
		return (my_pthread_t_element *) popFirst(runQueue2);
	}
	if (getLength(runQueue1) > 0) {
		return (my_pthread_t_element *) popFirst(runQueue1);
	}
	if (getLength(runQueue0) > 0) {
		return (my_pthread_t_element *) popFirst(runQueue0);
	}
	return NULL;
}

void scheduler_signal_handler(int signum) {
    //printf("entering signal handler\n");
	executionCounter++;
	if (executionCounter * DEFAULT_INTERVAL_2 >= 1000){
		resetPriorities();
		executionCounter = 0;
	}
	currentlyRunning->timesRan += DEFAULT_INTERVAL_2;
    //printf("here4 maybe? cR = %d\n", currentlyRunning->id);
	if (currentlyRunning->status == STATUS_DONE);
	else if (currentlyRunning->priority == 2){
		currentlyRunning->priority = 1;
		currentlyRunning->timesRan = 0;
		addLink(runQueue1, (void *) currentlyRunning);
	}
	else if (currentlyRunning->priority == 1){
		if (currentlyRunning->timesRan >= DEFAULT_INTERVAL_1){
			currentlyRunning->priority = 0;
			currentlyRunning->timesRan = 0;
			addLink(runQueue0, (void *) currentlyRunning);
		}
		else {
			return;
		}
	}
	else if (currentlyRunning->timesRan < DEFAULT_INTERVAL_0){
		initialized=3;	
		return;
	}
    //printf("here2 maybe?\n");
	if ( currentlyRunning->timesRan >= DEFAULT_INTERVAL_0 && currentlyRunning->priority == 0 && currentlyRunning->status != STATUS_DONE){
       // printf("here2 maybebefor?\n");
		addLink(runQueue0, (void *) currentlyRunning);
        //printf("here2 maybe after?\n");
	}
	my_pthread_t_element * myThread = getNextThread();
	if (myThread == NULL) {
		exit(0);
	}
	
	myThread->timesRan = 0;
    //printf("here maybe?\n");
    struct itimerval it_val;

    it_val.it_value.tv_sec = DEFAULT_INTERVAL_2 / 1000;
    it_val.it_value.tv_usec = (DEFAULT_INTERVAL_2 * 1000) % 1000000;
    it_val.it_interval = it_val.it_value;
	setitimer(ITIMER_VIRTUAL, &it_val, NULL);
	oldRunning = currentlyRunning;
	if (currentlyRunning->id != 1){
		int * threadFirstPage = ((int *) getHead(currentlyRunning->pages)->value);
	    int tempval = *threadFirstPage;
		mprotect(firstPage + PAGESIZE*tempval, PAGESIZE * currentlyRunning->pageCount, PROT_NONE);
	}
	currentlyRunning = myThread;
    //printf("About to run %d\n", currentlyRunning->id);
    swapcontext(&(oldRunning->context), &(myThread->context));
}

void swapPageIn(pageTableEntry * to){
	char * fromPage = swapSpace, *toPage = to->address;
	int i = 0;
	for (;i < PAGESIZE; i++){
		char temp = *(fromPage+i);
		*(fromPage + i) = *(toPage + i);
		*(toPage + i) = temp;
	}
}

void printpageorder(){
    int i = 0;
    while (i < 200){
        int * from = (int *) getLink(pageOrder, i)->value;
        printf("%d, ", *from);
        i++;
    }
}
//OUR SIGSEGV HANDLER
static void handler(int sig, siginfo_t *si, void *unused) {
    swapCounter++;
    //printf("in currently Running %d\n", currentlyRunning->id);
    pause_timer();
    if (si->si_addr > (void *) myblock + SIZE || si->si_addr < (void *) firstPage){
        printf("segfault\n");
       // printpageorder();
        exit(0);
    }
	unsigned long page = (((long) si->si_addr) - ((long) firstPage))/PAGESIZE;
	int oldPage = page;
    int * threadFirstPage = ((int *) getHead(currentlyRunning->pages)->value);
	int tempval = *threadFirstPage;
	if (tempval != page){
		page = *((int *) getLink(currentlyRunning->pages, page-currentlyRunning->firstPage)->value);
	}
    int * from = (int *) getLink(pageOrder, oldPage)->value;
     
    pageTableEntry * temp = getPageTableEntry(pTable, *from), * temp2 = getPageTableEntry(pTable, page);
    if (*from == page) {
        mprotect(temp->address, PAGESIZE, PROT_READ | PROT_WRITE);
        return;
    }
    if (temp2->inmem){
    	mprotect(temp->address, PAGESIZE, PROT_READ | PROT_WRITE);
    	readPageFromSwapFile(temp2->inmem);
    	writePageToSwapFile(*from);
    	swapPageIn(temp);
    	temp2->inmem = 0;
    	*from = page;
    	resume_timer();
    	return;
    }
    mprotect(temp->address, PAGESIZE, PROT_READ | PROT_WRITE);
    mprotect(temp2->address, PAGESIZE, PROT_READ | PROT_WRITE);
    breakFromSwapPage = 0;
    swapPages(*from, page);
    breakFromSwapPage = 1;	
    mprotect(temp2->address, PAGESIZE, PROT_NONE);
    resume_timer();
    //printf("out\n");
    return;

}

/*
 * Current context should be switched out and replaced with the next one
 * NOTE this does not change the priority of the thread that called it.
 */
void my_pthread_yield(){
    setitimer(ITIMER_VIRTUAL, &cancel_time, NULL);
    yielded = 1;
    scheduler_signal_handler(0);
}

/*
 * Blocking call that will not let the thread that called it until
 * the thread passed into the function completes.
 */
int my_pthread_join(my_pthread_t thread, void **value_ptr){
	while (1){
		my_pthread_t_element * a = getHash(threadQueue, (thread.id));
		if (a->status == STATUS_DONE){
			return 0;
		}
		my_pthread_yield();
	}
    return 0;
}
/**
 * Exists to be the context called once a thread function returns. During initialization,
 * we call this function, which saves it's current context and immediately switches back to 
 * the main context. The context saved here is to be linked to through uc_link.
 * Then once a context terminates, it will be brought to this code point where the
 * thread can be terminated properly. 
 */
void thread_terminated() {
	swapcontext(&finished_context, main_context);
	setitimer(ITIMER_VIRTUAL, &cancel_time, NULL);
	unsigned int id = currentlyRunning->id;
    my_pthread_t_element *me = getHash(threadQueue, id);
	me->status = STATUS_DONE;

	scheduler_signal_handler(0);
}
int isPageFree(int page){
    int outer = page/32;
    int inner = page % 32;
    if ((pageDirectory[outer] >> inner & 1)  == 0){
        return 1;
    }
    return 0;
}
int setPageFree(int page){
    int outer = page/32;
    int inner = page % 32;
    int k = 1 << inner;
    pageDirectory[outer] = pageDirectory[outer] ^ k; 
    return 0;
}
void pause_timer()
{
    setitimer(ITIMER_VIRTUAL, &cancel_time, &old_timer);
}

void resume_timer()
{
    setitimer(ITIMER_VIRTUAL, &old_timer, NULL);
}

void readPageFromSwapFile(int page){
	fseek(filedes, page*PAGESIZE, SEEK_SET);
	int a = fread(swapSpace, 1, PAGESIZE, filedes);
}

void * writePageToSwapFile(int toEvict){
	pageTableEntry * toEvictEntry = getPageTableEntry(pTable, toEvict);
	toEvictEntry->inmem = curFilePage;
	fseek(filedes, curFilePage*PAGESIZE, SEEK_SET);
	int a = fwrite(toEvictEntry->address , 1, PAGESIZE , filedes);
	curFilePage++;
	return toEvictEntry->address;
}
int test_func(){
	writePageToSwapFile(1);
	// printf("currentlyRunning %d pages %d\n", currentlyRunning->id, currentlyRunning->pages->length);
	// pageTableEntry * toEvictEntry = getPageTableEntry(pTable, 7);
	// char * a = (char *) toEvictEntry->address;
	// int i = 0;
	// for (; i < 100; i++){
	// 	a[i] = 'i';
	// }
	// a[i] = '\0';
	// writePageToSwapFile(7);
	// i = 0;
	// for (; i < 100; i++){
	// 	a[i] = 'j';
	// }
	// writePageToSwapFile(7);
	// a = (char *) swapSpace;
	// printf("swapSpace ='%s'\n", a);
	// readPageFromSwapFile(1);
	// printf("swapSpace ='%s'\n", a);
	// readPageFromSwapFile(2);
	// printf("swapSpace ='%s'\n", a);
}
int test_func2(){
	printf("currentlyRunning %d\n", currentlyRunning->id);
}

int getNextFreePage(){
    int i = 0;
    while (!isPageFree(i++)){
    	if (i >= total_pages) {
    		if (curFilePage * PAGESIZE > FILESIZE){
    			return -1;
    		}
    		pause_timer();
    		int random = rand() % 1000;
    		int toEvict = *((int *) getLink(pageOrder, random)->value);
    		void * address = writePageToSwapFile(toEvict);
    		pageTableEntry * toInsert = mymallocPage(systemMemory, MALLOC_CONST, sizeof(pageTableEntry), __FILE__, __LINE__, 2);
	    	toInsert->address = address;
	    	toInsert->inmem = 0;
	    	unsigned int oldPagePlace = (address - firstPage)/PAGESIZE;
			int * temp1 = (int *) getLink(pageOrder, oldPagePlace)->value;
	    	*temp1 = total_pages;
	    	insertPageTable(pTable, toInsert);
	    	total_pages++;
	    	int k = 1 << (i % 32);
    		pageDirectory[i/32] = pageDirectory[i/32] | k;
	    	resume_timer();
	    	return *temp1;
    	}
    }
    i--;
    int k = 1 << (i % 32);
    pageDirectory[i/32] = pageDirectory[i/32] | k;
    return i;
}
/**
 * Initializes the memory, it saves LIBRARY_MEM amount of memory for the library and 
 * then reserves PAGE_SIZE amounts until the memory fills up
 */
void initMemory(){
	if (!myblock){
		posix_memalign((void *)&myblock, sysconf(_SC_PAGE_SIZE), SIZE);
        memset(myblock, 0, SIZE);
    }
    systemMemory = myblock;
    pTable = initPageTable();
    pageOrder = initList();
    swapSpace = systemMemory + LIBRARY_MEM*PAGESIZE;
    firstPage = swapSpace + PAGESIZE;
    int i = 0;
    while (LIBRARY_MEM*PAGESIZE + PAGESIZE +i*PAGESIZE < SIZE) {
    	pageTableEntry * toInsert = mymallocPage(systemMemory, MALLOC_CONST, sizeof(pageTableEntry), __FILE__, __LINE__, 2);
    	toInsert->address = firstPage + i*PAGESIZE;
    	toInsert->inmem = 0;
    	int * pageOrderID = mymallocPage(systemMemory, MALLOC_CONST, sizeof(int), __FILE__, __LINE__, 2);
    	*pageOrderID = total_pages;
    	insertPageTable(pTable, toInsert);
    	addLink(pageOrder, (void * ) pageOrderID);
    	i++;
    	total_pages++;
    }
    pageDirectory = mymallocPage(systemMemory, MALLOC_CONST, sizeof(int) * ((total_pages + (FILESIZE/PAGESIZE)/32) + 1), __FILE__, __LINE__, 2);
    i = 0;
    for (; i < ((total_pages/32) + 1); i++)
         pageDirectory[i] = 0;
    filedes = fopen("./swapfile.txt", "w+");
    if (!filedes){
        filedes = fopen("./swapfile.txt", "r+");
    }
    fseek(filedes, FILESIZE, SEEK_SET);
    fputc('\0', filedes);
}
/**
 * Initializes the threading library. Creates the queues, creates an entry
 * for the main context, and sets the first timer. This is to be called
 * at the beginning of my_pthread_create() as it is only when we add more threads
 * that the library needs to be initialized.
 */
void ensureInitialized() {
	if (!initialized) { // if uninitialized
		srand(time(NULL));
        initMemory();
        struct sigaction sa;
        sa.sa_flags = SA_SIGINFO;
        sigemptyset(&sa.sa_mask);
        sa.sa_sigaction = handler;

        if (sigaction(SIGSEGV, &sa, NULL) == -1)
        {
            printf("Fatal error setting up signal handler\n");
            exit(EXIT_FAILURE);    //explode!
        }
		initialized = 1;
		// attach interrupt handler
		signal(SIGVTALRM, scheduler_signal_handler);
		// initialize queues
		threadQueue = initHash();
		runQueue0 = initList();
		runQueue1 = initList();
		runQueue2 = initList();

		waitQueue = initList();
		mutexQueue = initHashMutex();
		// add main thread to queue
		my_pthread_t_element * toAdd = mymallocPage(systemMemory, MALLOC_CONST, sizeof(my_pthread_t_element), __FILE__, __LINE__, 2);
		main_context = &(toAdd->context);
		unsigned int * heapID = mymallocPage(systemMemory, MALLOC_CONST, sizeof(int) , __FILE__, __LINE__, 2);
		*heapID = ID;
		toAdd->id = ID++;
		toAdd->priority = 2;
		toAdd->status = STATUS_RUNNING;
		currentlyRunning = toAdd;
		insertHash(threadQueue, toAdd);
		addLink(runQueue2, (void *) toAdd);
		// set up termination context

        // printf("after addLink\n");
		getcontext(&(finished_context));
		finished_context.uc_link = 0;
		finished_context.uc_stack.ss_sp = mymallocPage(systemMemory, MALLOC_CONST, DEFAULT_STACK_SIZE, __FILE__, __LINE__, 2);
		finished_context.uc_stack.ss_size = DEFAULT_STACK_SIZE;
		finished_context.uc_stack.ss_flags = 0;
		makecontext(&finished_context, (void *)thread_terminated, 0, NULL);
		swapcontext(main_context, &finished_context);
		// set timer to go off
		struct itimerval it_val;
		it_val.it_value.tv_sec = DEFAULT_INTERVAL_2 / 1000;
		it_val.it_value.tv_usec = (DEFAULT_INTERVAL_2	 * 1000) % 1000000;
		it_val.it_interval = it_val.it_value;
		setitimer(ITIMER_VIRTUAL, &it_val, NULL);
	}
}

int my_pthread_create(my_pthread_t * thread, my_pthread_attr_t * attr, void *(*function)(void*), void * arg) {
	if (!thread) return EINVAL;
	if (!initialized)
		ensureInitialized();
	my_pthread_t_element * toInsert = mymallocPage(systemMemory, MALLOC_CONST, sizeof(my_pthread_t_element), __FILE__, __LINE__, 2);
	toInsert->id = ID;

	//Set up the first page of memory for the thread
	int * firstPageID = (int *) mymallocPage(systemMemory, MALLOC_CONST, sizeof(int), __FILE__, __LINE__, 2);
	*firstPageID = getNextFreePage();
    toInsert->firstPage = *firstPageID;
    toInsert->pageCount = 1;
    toInsert->pages = initList();
    addLink(toInsert->pages, (void *)firstPageID);
	toInsert->priority=2;
	int * heapID = mymallocPage(systemMemory, MALLOC_CONST, sizeof(int), __FILE__, __LINE__, 2);
	*heapID = ID;
	thread->id = ID++;
	getcontext(&(toInsert->context));
    toInsert->context.uc_link = &finished_context;
    toInsert->context.uc_stack.ss_sp = mymallocPage(systemMemory, MALLOC_CONST, DEFAULT_STACK_SIZE, __FILE__, __LINE__, 2);
    toInsert->context.uc_stack.ss_size = DEFAULT_STACK_SIZE;
    toInsert->context.uc_stack.ss_flags = 0;
    if (!toInsert->context.uc_stack.ss_sp) {
		return EAGAIN;
	}
    makecontext(&(toInsert->context), (void *)function, 1, arg);
    toInsert->status = STATUS_QUEUED;
    insertHash(threadQueue, toInsert);
    addLink(runQueue2, (void *) toInsert);
    return 0;
}

int my_pthread_mutex_init(my_pthread_mutex_t *mutex, const my_pthread_mutexattr_t *mutexattr){
	if (!initialized)
		ensureInitialized();
	mutex->id = MUTEX_ID;
	my_pthread_mutex_t_element * toInsert = mymallocPage(systemMemory, MALLOC_CONST, sizeof(my_pthread_mutex_t_element), __FILE__, __LINE__, 2);
	toInsert->waiting = initList();
	toInsert->id = MUTEX_ID++;
	toInsert->owner = 0;
	toInsert->destroyed = 0;
	toInsert->lock = 0;
	insertHashMutex(mutexQueue, toInsert);
	return 0;
}
//if returns 1 you dont have it, 0 you have it
int testAndSet(volatile int *ptr) {
	
	volatile int oldval = 1;
	
	__asm__ __volatile__(
		" lock          \n"
		" btsl $0, (%0) \n"
		" jc .L%=       \n"
		" movl $0, %1   \n"
		" .L%=:         \n"
		: "=r" (ptr), "=m" (oldval)
	);
	
	return oldval;
}

int my_pthread_mutex_lock(my_pthread_mutex_t *mutex){
	int first = 1;
	while (1){
		my_pthread_mutex_t_element * a = getHashMutex(mutexQueue, (mutex->id));
		if (a->destroyed){
			return EINVAL;
		}
		if (testAndSet(&(a->lock))){
			if (first){
				addLink(a->waiting, currentlyRunning);
				first = 0;
			}
			my_pthread_yield();
		}
		else {

			if (getLength(a->waiting) == 0){
				a->owner = currentlyRunning->id;
				break;
			}
			my_pthread_t_element * nextOwner = (my_pthread_t_element *) peekFirst(a->waiting);
			if (nextOwner->id == currentlyRunning->id){
				a->owner = currentlyRunning->id;
				popFirst(a->waiting);
				break;
			}
			a->lock=0;
			my_pthread_yield();

		}
	}
    return 0;
}

int my_pthread_mutex_unlock(my_pthread_mutex_t *mutex){
	my_pthread_mutex_t_element * a = getHashMutex(mutexQueue, (mutex->id));
	if (a->destroyed){
		return EINVAL;
	}
	if (currentlyRunning->id == a->owner){
		a->lock = 0;
		a->owner = 0;
		return 0;
	}else {
		return EINVAL;
	}

}

int my_pthread_mutex_destroy(my_pthread_mutex_t *mutex){
	int tryUnlock = my_pthread_mutex_unlock(mutex);
	if (tryUnlock != 0){
		return tryUnlock;
	}
	my_pthread_mutex_t_element * a = getHashMutex(mutexQueue, (mutex->id));
	a->destroyed = 1;
	return 0;
}

void my_pthread_exit(void *value_ptr) {
	setitimer(ITIMER_VIRTUAL, &cancel_time, NULL);
	unsigned int id = currentlyRunning->id;
    my_pthread_t_element *me = getHash(threadQueue, id);
	me->status = STATUS_DONE;
	scheduler_signal_handler(0);
}
