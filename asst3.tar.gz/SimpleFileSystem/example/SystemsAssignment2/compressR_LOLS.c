#include "compressR_LOLS.h"

void execCall(char * inputFileStr, int start, int end, char * filename){
	char chrStart[20];
	sprintf(chrStart, "%d", start);
	char chrEnd[20];
	sprintf(chrEnd, "%d", end);
	execl("./worker","worker", inputFileStr, chrStart, chrEnd, filename, (char *)0);
}

void compressR_LOLS(char * filename, int numWorkers){
	FILE *fp = fopen(filename, "r");
	int lenChar = 0;
	char c;
	while((c=fgetc(fp))) {
		if(c == EOF) 
			break;
		if (!isalpha(c)) 
			continue;
		lenChar++;
	}
	fclose(fp);
	int * processes = malloc(sizeof(int)  * numWorkers);
	int i = 0, prev = 0;
	int offset = lenChar % numWorkers;
	for (; i < numWorkers; i++){
		processes[i] = fork();
		if (processes[i] == 0){
			char * a;
			if (numWorkers != 1){
				a = filenamer(filename, i);	
			} else{
				a = filenamer(filename, -1);	
			}
			if (i == 0){
				execCall(filename, prev, prev + (lenChar/numWorkers) + offset, a);
			}
			else{
				execCall(filename, prev+ offset, prev + (lenChar/numWorkers) + offset, a);
			}
			free(a);
		}
		prev += lenChar/numWorkers;
	}
	i = 0;
	for (; i < numWorkers; i++){
		waitpid(processes[i], 0,0);
	}
	free(processes);
}

int main(int argc, char const *argv[])
{	
	if (argc != 3){
		printf("Usage: ./compressR_LOLS <name of file> <number of workers>\n");
		exit(1);
	}
	int numWorkers= atoi(argv[2]); 
	char * temp = (char *) argv[1];
	if( access( argv[1], R_OK ) == -1 ) {
    	printf("File '%s' not found or do not have proper permissions.\n", argv[1]);
    	exit(1);
	} 
	compressR_LOLS(temp, numWorkers);
	return 0;
}