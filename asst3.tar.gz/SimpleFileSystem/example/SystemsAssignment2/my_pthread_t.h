
#ifndef __MY_PTHREAD_T_H
#  define __MY_PTHREAD_T_H

#  include <ucontext.h>
#  include <sys/time.h>
#define THREADMEMCONSTANT 0
#define malloc( x ) mymalloc( x, __FILE__, __LINE__, THREADMEMCONSTANT)
#define calloc( x, y ) mymalloc( x, __FILE__, __LINE__, THREADMEMCONSTANT)
#define free( x ) myfree( x, __FILE__, __LINE__,  THREADMEMCONSTANT)
#  define MUTEX_MAGIC 0xFCFCFCFC
//!!!!! LINKED LIST H FILE
typedef struct {
	void *value;
	void *prev;
	void *next;
} LinkedNode;

typedef struct {
	int length;
	int index;
	LinkedNode *cur;
	LinkedNode *head;
	LinkedNode *tail;
} LinkedList;

#  define  getNext(nd) ((LinkedNode *) nd->next)
#  define  getPrev(nd) ((LinkedNode *) nd->prev)
#  define  getHead(lst) ((LinkedNode *) lst->head)
#  define  getTail(lst) ((LinkedNode *) lst->tail)

#  define  getValue(nd, type) ((type *) nd->value)

LinkedList *initList();
void addLink(LinkedList *list, void *val);
void insertLink(LinkedList *list, void *val, int index);
LinkedNode *getLink(LinkedList *list, int index);
void *removeElem(LinkedList *list, void *val);
void *peekElem(LinkedList *list, int index);
void * findID(LinkedList * list, unsigned int id);
void *popElem(LinkedList *list, int index);
void *peekFirst(LinkedList *list);
void *popFirst(LinkedList *list);
void *peekLast(LinkedList *list);
void *popLast(LinkedList *list);

typedef struct{
	unsigned int id;
} my_pthread_t;

typedef struct {
    ucontext_t context;
    int priority, status, id, timesRan, join, pageCount, firstPage;
    LinkedList * pages;
    void *retval;
} my_pthread_t_element;

typedef struct {
	unsigned int id;
} my_pthread_mutex_t;

typedef struct {
	unsigned int id;
	LinkedList *waiting;
	void *value_ptr;
	int lock, owner, magic, destroyed;
} my_pthread_mutex_t_element;

typedef struct {
	void * address;
	unsigned short inmem;
} pageTableEntry;

typedef struct {
	unsigned int curLen;
	unsigned int curMaxLen;
	int ** heap;
} heap;

typedef struct {
	unsigned int curLen;
	unsigned int curMaxLen;
	my_pthread_t_element ** hash;
} hash;

typedef struct {
	unsigned int curLen;
	unsigned int curMaxLen;
	my_pthread_mutex_t_element ** hash;
} mutexhash;

typedef struct {
	unsigned int curLen;
	unsigned int curMaxLen;
	pageTableEntry ** hash;
} pageTable;

#  define STATUS_WAITING 1
#  define STATUS_QUEUED  2
#  define STATUS_RUNNING 3
#  define STATUS_DONE    4


// dummy typedefs for consistency
typedef int my_pthread_attr_t;
typedef int my_pthread_mutexattr_t;

int my_pthread_create(my_pthread_t * thread, my_pthread_attr_t * attr, void *(*function)(void*), void * arg);
void my_pthread_yield();
void my_pthread_exit(void *value_ptr);
int my_pthread_join(my_pthread_t thread, void **value_ptr);
 
 
int my_pthread_mutex_init(my_pthread_mutex_t *mutex, const my_pthread_mutexattr_t *mutexattr);
int my_pthread_mutex_lock(my_pthread_mutex_t *mutex);
int my_pthread_mutex_unlock(my_pthread_mutex_t *mutex);
void pause_timer();
void resume_timer();
int my_pthread_mutex_destroy(my_pthread_mutex_t *mutex);

void * split(int * p, int bytesOrOne, int toAdd);
void * mymalloc(int bytes, char * file, int line, int THREADREQ);
void myfree(void * toFree, char * file, int line, int THREADREQ);
void combine();
void printHeap();
void * mymallocPage(char * tempblock, int pageSize, int bytes, char * file, int line, int THREADREQ);
int getNextFreePage();
int setPageFree(int page);
pageTable * initPageTable();
void insertPageTable(pageTable * h, pageTableEntry * toInsert);
pageTableEntry * getPageTableEntry(pageTable * h, int id);
void printMallocHeapPage(char * tempblock, int pageSize);
void readPageFromSwapFile(int page);
void * writePageToSwapFile(int toEvict);
#endif
