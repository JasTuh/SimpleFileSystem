#include <stdio.h>
#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include  <sys/types.h>
#include <unistd.h> 
#include <pthread.h>
#include "sharedmethods.h"

/**
 * This is the struct I use to pass the arguments to my shorten arguments 
 * in threads 
 */
struct _shortenargs {
  char * inputFileStr;
  int start;
  int end;
  char * filename;
};

typedef struct _shortenargs shortenargs;


/**
 * Implements the compression algorithm takes in a memory address to a shortenargs 
 * struct
 */
void * shorten(void * arguments);


/**
 * A method that is given a file name and the number of workers
 * and then spawns that number of threads that compress the file
 */
void compressT_LOLS(char * filename, int numWorkers);