#include "compressR_worker_LOLS.h"

void shorten(char * inputFileStr, int start, int end, char * filename){
	FILE *fp, *inputFile;
	inputFile = fopen(inputFileStr, "r");
   	fp = fopen(filename, "w+");
	char * toReturn = malloc(sizeof(char) * (end-start + 1));
	char currentChar;
	int inARow = 1, curIndex = 0, stringIndex=0;
	while(curIndex != start) {
    	currentChar=fgetc(inputFile);
    	if(currentChar == EOF) 
    		break;
    	if (!isalpha(currentChar)){
    		continue;
    	}
  		curIndex++;
  	}
  	currentChar = fgetc(inputFile);
  	while (!isalpha(currentChar)){
		  	currentChar = fgetc(inputFile);
		}
	while (curIndex < end){
		char temp;
		while (++curIndex < end){
			temp = fgetc(inputFile);

			if (temp == currentChar)
				inARow++;
			else{
				if (temp == EOF){
					break;
				}
				if (isalpha(temp)){
					break;
				}
				curIndex--;
			}
		}
		char buffer[20];
		sprintf(buffer, "%d", inARow);
		int bufIndex = 0;

		if (inARow > 2){
			while (buffer[bufIndex] != '\0'){
				toReturn[stringIndex++] = buffer[bufIndex++];
			}
		}
		if (inARow == 2)
			toReturn[stringIndex++] = currentChar;

		toReturn[stringIndex++] = currentChar;
		inARow = 1;
		currentChar = temp;
		while (curIndex < end && !isalpha(currentChar)){
		  	currentChar = fgetc(inputFile);
		}
		
	}
	toReturn[stringIndex++] = '\0';
	fprintf(fp, "%s", toReturn);
   	fclose(fp);
   	free(toReturn);
}
int main(int argc, char const *argv[])
{	
	
	char * temp = (char *) argv[1];
	int start = atoi(argv[2]);
	int end = atoi(argv[3]);
	char * temp2 = (char *) argv[4];
	shorten(temp, start, end, temp2);
	return 0;
}