
/**
 * Takes in an integer and returns the length of it
 * for instance 15 returns 2
 */
int intlen(int a){
	int length = 1;
	a/=10;
	while (a != 0){
		a++;
		a/=10;
	}
	return length;
}

/**
 * Takes in a string and a worker number and formats
 * the string correctly to match the assignment description
 * if the method is given worker = -1 it doesn't put any number after the name
 */
char * filenamer(char * filename, int worker){
	char * toReturn = malloc(sizeof(char) * (6 + strlen(filename) + intlen(worker)));
	if (worker != -1)
		sprintf(toReturn, "%s_LOLS%d", filename, worker);
	else
		sprintf(toReturn, "%s_LOLS", filename);
	int i = 0;
	if (strlen(toReturn) > 2 && toReturn[0] == '.' && toReturn[1] == '/'){
		i = 2;
	}
	for(; i < strlen(toReturn); i++){
		if(toReturn[i] == '.'){
			toReturn[i] = '_'; 
		} 
	}
	return toReturn;
}
