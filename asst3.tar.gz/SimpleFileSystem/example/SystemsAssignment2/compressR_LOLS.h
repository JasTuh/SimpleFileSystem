#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <ctype.h>
#include  <sys/types.h>
#include <unistd.h> 
#include "sharedmethods.h"

/**
 * Implements the compression algorithm takes in a memory address to a shortenargs 
 * struct
 */
void * shorten(void * arguments);

/**
 * makes an exec call that starts the worker off, converts the ints to strings first
 **/ 
void execCall(char * inputFileStr, int start, int end, char * filename);

/**
 * A method that is given a file name and the number of workers
 * and then spawns that number of threads that compress the file
 */
void compressR_LOLS(char * filename, int numWorkers);
