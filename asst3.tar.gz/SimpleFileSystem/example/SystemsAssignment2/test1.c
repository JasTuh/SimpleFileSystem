#include <stdio.h>
#include <stdlib.h>
#include "my_pthread_t.h"

static volatile int id = 1;

void *test_thread (void *ptr) {
	int id = *((int *) ptr);
	int size = *((int *) (ptr + sizeof(int)));
	int **array = malloc(sizeof(int *) * size);
	int i;
	
	for (i=0; i<size; i++) {
        int random = rand() % 25;
        if (random == 12){
            my_pthread_yield();
        }
		array[i] = malloc(2048);
		printf("Thread %03d: getting 512 bytes from %lu\n", id, (long) array[i]);
	} 
	
	printf("Thread %03d: Waiting 1000 loops\n", id);
	
	for (i=0; i<1000; i++) {
        char * a = (char *) array[i];
		my_pthread_yield();
		if (i % 500 == 0) {
            printf("Thread %03d\n", id);
        }
	}
	
	for (i=0; i<size; i++) {
		free(array[i]);
	}
}

int main(int argc, char *argv[]) {
	int threadCnt = 10;
    srand(time(NULL));
	int *a = malloc(4096*2); // malloc 2 pages
	printf("Page starting at %lu\n", (long) a);
	printf("Starting threads to take up a lot of memory\n");
	my_pthread_t *thing = malloc(sizeof(my_pthread_t) * threadCnt);
	int i = 0;
	int *vals = malloc(sizeof(int) * 2 * threadCnt);
	
	//vals[0] = id++;
	//vals[1] = 500;	// if you change this to 400 it doesn't seg fault
	//test_thread(vals);
	
	for (i=0; i<threadCnt; i++) {
		vals[i*2] = id++;
		vals[i*2+1] = 100;
		my_pthread_create(&thing[i], NULL, &test_thread, &(vals[i*2]));
	}
	
	
	for (i=0; i<10; i++) {
		my_pthread_join(thing[i], NULL);
	}
	
	free(a);
}
