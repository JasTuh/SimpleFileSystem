#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <ctype.h>
#include  <sys/types.h>
#include <unistd.h> 


/**
 * Takes in an inputfilestring that it reads and compresses from start to end
 * it outputs it into a file with the filename given
 */
void shorten(char * inputFileStr, int start, int end, char * filename);