#include "compressT_LOLS.h"
#include "my_pthread_t.h"
void * shorten(void * arguments){
	shortenargs *temp = (shortenargs *) arguments;

	char * inputFileStr = temp->inputFileStr;
	int start = temp->start;
	int end = temp->end;
	char * filename = temp->filename;
	FILE *fp, *inputFile;
	inputFile = fopen(inputFileStr, "r");
   	fp = fopen(filename, "w+");
    if (!fp){
        printf("file %s already exists please delete it", filename);
        exit(0);
    }
	char * toReturn = malloc(sizeof(char) * (end-start + 1));
	char currentChar;
	int inARow = 1, curIndex = 0, stringIndex=0;
    while(curIndex != start) {
    	currentChar=fgetc(inputFile);
    	if(currentChar == EOF) 
    		break;
    	if (!isalpha(currentChar)){
    		continue;
    	}
  		curIndex++;
  	}
  	currentChar = fgetc(inputFile);
  	while (!isalpha(currentChar)){
		  	currentChar = fgetc(inputFile);
		}
	while (curIndex < end){
		char temp;
		while (++curIndex < end){
			temp = fgetc(inputFile);

			if (temp == currentChar)
				inARow++;
			else{
				if (temp == EOF){
					break;
				}
				if (isalpha(temp)){
					break;
				}
				curIndex--;
			}
		}
		char buffer[20];
		sprintf(buffer, "%d", inARow);
		int bufIndex = 0;

		if (inARow > 2){
			while (buffer[bufIndex] != '\0'){
				toReturn[stringIndex++] = buffer[bufIndex++];
			}
		}
		if (inARow == 2)
			toReturn[stringIndex++] = currentChar;

		toReturn[stringIndex++] = currentChar;
		inARow = 1;
		currentChar = temp;
		while (curIndex < end && !isalpha(currentChar)){
		  	currentChar = fgetc(inputFile);
		}
		
	}
	toReturn[stringIndex++] = '\0';
	fprintf(fp, "%s", toReturn);
   	fclose(fp);
   	free(toReturn);
   	free(arguments);
   	return NULL;
}
void compressT_LOLS(char * filename, int numWorkers){
	FILE *fp = fopen(filename, "r");
	int lenChar = 0;
	char c;
	while((c=fgetc(fp))) {
		if(c == EOF) 
			break;
		if (!isalpha(c)){
			continue;
		}
		lenChar++;
	}
	fclose(fp);
	my_pthread_t * threads = malloc(sizeof(my_pthread_t)  * numWorkers);
	int i = 0, prev = numWorkers;
	i = 0, prev = 0;
	int offset = lenChar % numWorkers;
	for (; i < numWorkers; i++){
		char * a;
		if (numWorkers == 1){
			a = filenamer(filename, -1);
		}
		else{
			a = filenamer(filename, i);
		}
		shortenargs * temp = malloc(sizeof(shortenargs));
		temp->inputFileStr = malloc(sizeof(char) * strlen(filename));
		strcpy(temp->inputFileStr, filename);
		if (i == 0){
			temp->start = prev;
			temp->end = prev + (lenChar/numWorkers) + offset;
		}
		else {
			temp->start = prev+ offset;
			temp->end = prev + offset+ (lenChar/numWorkers);
		}
		temp->filename = a;
		my_pthread_create(&threads[i], NULL, shorten, temp);	
		prev += lenChar/numWorkers;
	}
	i = 0, prev = 0;
	for (; i < numWorkers; i++){
		my_pthread_join(threads[i], NULL);
	}
	free(threads);
}

int main(int argc, char const *argv[])
{	
	if (argc != 3){
		printf("Usage: ./compressT_LOLS <name of file> <number of workers>\n");
		exit(1);
	}
	
	int numWorkers= atoi(argv[2]); 
	char * temp = (char *) argv[1];
	if( access( argv[1], R_OK ) == -1 ) {
    	printf("File '%s' not found or do not have proper permissions.\n", argv[1]);
    	exit(1);
	} 
	compressT_LOLS(temp, numWorkers);
	return 0;
}
